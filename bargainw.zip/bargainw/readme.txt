use scrapy only
pip install scrapy, will work
